/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projet_poo;

/**
 *
 * @author ali abdelhak
 */
public class etudiant {
    private String nom;
    private String prenom;
    private String groupe;
    private String ncin;
    private int score;
    public etudiant(String nom_et,String prenom_et,String groupe_et,String ncin_et,int scoree){
        nom=nom_et;
        prenom=prenom_et;
        groupe=groupe_et;
        ncin=ncin_et;
        score=scoree;
    }
    public String access_nom(){
        return nom;
    }
    public String access_prenom(){
        return prenom;
    }
    public String access_groupe(){
        return groupe;
    }
    public String access_ncin(){
        return ncin;
    }
    public int access_score(){
        return score;
    }

    public void afficher(){
        System.out.println("\n\n");
        System.out.println("             nom : "+nom);
        System.out.println("             prenom : "+prenom);
        System.out.println("             groupe : "+groupe);
        System.out.println("             nom : "+ncin);
        System.out.println("             score : "+score);
    }
}
