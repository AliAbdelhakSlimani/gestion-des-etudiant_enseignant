/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projet_poo;
import java.util.*;
/**
 *
 * @author ali abdelhak
 */
public class OPTION {
    private String Texte;
    private String rep;//true si valide on va attribuer 1 si valide et 0 si non valide et pour chaque qcm on va compter si le nombre des réponses valides et plus hauts que les réponses non valides alors on va attribuer une pourcentage si on a 2 qcm et un est valide alors il reçoit 50% car ce qcm présente la moititié dans le pourcentage est calculée en comptons combien d'une qcm (1/nbre de qcm)*(score (1"qcm validée",0"qcm non validée")*100)
    private String rep_et;
    public OPTION(String text,String repo){
        Texte=text;
        rep=repo;
    }
    public String access_repOP(){
        return rep;
    }
    public void afficher(String type){
        if(type.equals("ENSEIGNANT")==true){
            System.out.println("             \n . text option :"+Texte+" ");
            System.out.println("\n                       reponse a l'option : "+rep+"\n");
        }
        else{

            System.out.println("             \n . text option :"+Texte+" ");
        
        }
    }
    public void modifier(){
        Scanner sc=new Scanner(System.in);
        String reponse;
        do{
            System.out.print("\nest ce que vous voulez modifier le text et le reponse(deux/DEUX) ou seulement la reponse(rep/REP) ou seulement le texte(text/TEXT) ou aucun de ces dernier(AUCUN/aucun)\n");
            reponse=sc.nextLine();
            reponse=reponse.toUpperCase();
        }while(reponse.equals("REP")==false && reponse.equals("TEXT")==false && reponse.equals("DEUX")==false && reponse.equals("AUCUN")==false);
        if(reponse.equals("DEUX")==true){
            System.out.print("donner le texte qui va remplacer "+ Texte + " : ");
            String remp=sc.nextLine();
            String repo;
           do{
                System.out.print("donner la réponse qui va remplacer la réponse "+ rep + " seulement (true)/(false) sont acceptable : ");
                repo=sc.nextLine();
            }while(repo.toUpperCase().equals("TRUE")==false && repo.toUpperCase().equals("FALSE")==false);
            Texte=remp;
            rep=repo;
        }else{
            if(reponse.equals("TEXT")==true){
            System.out.print("donner le texte qui va remplacer "+ Texte + " : ");
            String remp=sc.nextLine();
            Texte=remp;
            }
            else{
                if(reponse.equals("REP")==true){
                    String repo;
                    do{
                        System.out.print("donner la réponse qui va remplacer la réponse"+ rep + " seulement (true)/(false) sont acceptable : ");
                        repo=sc.nextLine();
                    }while(repo.toUpperCase().equals("TRUE")==false && repo.toUpperCase().equals("FALSE")==false);
                    rep=repo;
                }
            }
        }
    }
    
}

