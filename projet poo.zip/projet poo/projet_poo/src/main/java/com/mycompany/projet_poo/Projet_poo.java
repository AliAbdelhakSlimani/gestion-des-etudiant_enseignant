/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projet_poo;
import java.util.*;
/**
 *
 * @author ali abdelhak
 */
public class Projet_poo {
    public static String get_out_ens(String changer){
        Scanner sc=new Scanner(System.in);
        do{
                    System.out.print("tu veux changer le compte pour entrer comme un étudiant (o/O) pour oui et (n/N) pour non : ");
                    changer=sc.nextLine();
                    changer=changer.toUpperCase();
                }while(changer.equals("O")==false && changer.equals("N")==false ); 
        return changer;
    }
    public static String get_out_etud(String changer){
        Scanner sc=new Scanner(System.in);
        do{
                    System.out.print("tu veux quitter ce compte o/O pour oui et n/N pour non");
                    changer=sc.nextLine();
                    changer=changer.toUpperCase();
        }while(changer.equals("O")==false && changer.equals("N")==false ); 
           return changer;     
    }
    public static int etud_affiche()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("\n\n\nchoisir ce que vous voulez faire de cette application comme etudiant\n");
                    System.out.println("                 1)Visualiser la liste des Quiz disponibles en indiquant, ceux auxquels vous avez déjà répondu et ceux qu’ils vous n'avez pas encore passés. et répondre au quiz d'un module\n");

                    System.out.println("                 2)Consulter les scores obtenus pour les Quiz que vous avez déjà passés.\n");
                    System.out.println("                 3)Consulter la correction d’un Quiz \n");
                    System.out.println("                 4)quitter ce compte");
                    int rep;
                    System.out.println("\n\n");
                    do{
                        System.out.printf(" Réponse (de (1..4) :");
                        rep=sc.nextInt();
                    }while(rep>4 || rep<1);
        return rep;
    }
    public static void recursive_etud(ArrayList<QUIZ> tabquiz,ArrayList<etudiant> tabetudiant,String ncin,String nom,String prenom,String groupe)
    {
        int rep=etud_affiche();
        Scanner sc=new Scanner(System.in);
        String changer="";
        
        switch (rep){ 
            case (1):
                if(tabquiz.isEmpty()==false){
                String REP;
                boolean exist;
                int j;
                for(int i=0;i<tabquiz.size();i++){
                    exist=false;
                    j=0;
                    while(j<tabquiz.get(i).acces_etud().size() && exist==false){
                        
                        if(tabquiz.get(i).acces_etud().get(j).access_ncin().equals(ncin)==true){
                            System.out.println("l'étudiant de ncin "+ncin +" a passer le quiz qui a pour module "+tabquiz.get(i).accestheme() + " et pour enseignant " + tabquiz.get(i).acces());
                            exist=true;
                        }
                        j++;
                    }
                    //reponse au quiz et affichage du quiz disponible
                    if(exist==false){
                        tabquiz.get(i).afficher("ETUDIANT");
                        do{
                        System.out.println("\n\nest ce que vous voulez passez cette quiz o/O pour oui et n/N pour non");
                        REP=sc.nextLine();
                        REP=REP.toUpperCase();
                        }while(REP.equals("N")==false && REP.equals("O")==false);
                        if(REP.equals("O")==true){
                            //yaadi l qcm w baaed yzidou bsh ynajjem yehseb escore mteeou
                            int score=0;
                            int scoreQCM;
                            String repQCM;
                            int compteurOP;
                            for (int k=0;k<tabquiz.get(i).access_qcm().size();k++){
                                scoreQCM=1;
                                compteurOP=0;
                                System.out.println("QCM "+ k + " : ");
                                do{
                                    do{
                                        System.out.println("est ce que vous voulez cochez option N° "+(compteurOP+1)+ " pour le question n°"+ (k+1) +" true/TRUE pour oui et false/FALSE pour non: ");
                                        repQCM=sc.nextLine();
                                        repQCM=repQCM.toUpperCase();
                                    }while(repQCM.equals("TRUE")==false && repQCM.equals("FALSE")==false);
                                    if(repQCM.equals(tabquiz.get(i).access_qcm().get(k).access_tabop().get(compteurOP).access_repOP())==false){
                                        scoreQCM=0;
                                    }
                                    compteurOP++;
                                }while(compteurOP<tabquiz.get(i).access_qcm().get(k).access_tabop().size() );
                                tabquiz.get(i).access_qcm().get(k).settabrep(scoreQCM);
                                score=score+scoreQCM;
                                                                
                            }
                            score=(score*100)/tabquiz.get(i).access_qcm().size();
                            System.out.printf("\n\n-------------------------votre score : %d%%--------------------------------------\n\n",score);
                            etudiant et=new etudiant(nom,prenom,groupe,ncin,score);
                           tabquiz.get(i).ajouteretudiant(et);
                           String correction ;
                           do{
                           System.out.println("si vous voulez la correction de cette quiz écrire o/O si non n/N ");
                           correction=sc.nextLine();
                           correction =correction.toUpperCase();
                           }while(correction.equals("O")==false && correction.equals("N")==false);
                           if(correction.equals("O")==true){
                                tabquiz.get(i).afficher("ENSEIGNANT");
                           }
                           //yabda yaadi feha w ne7seblou score
                        }
                    }
                }
                
                changer=get_out_etud(changer);
                if(changer.equals("N")==true){
                    clearConsole();
                    recursive_etud(tabquiz,tabetudiant,ncin,nom,prenom,groupe);
                    break;
                }
                else{
                    break;
                }
                }
                else{
                    System.out.println("il ny'a aucun quiz pour ce moment");
                    changer=get_out_etud(changer);
                if(changer.equals("N")==true){
                    clearConsole();
                    recursive_etud(tabquiz,tabetudiant,ncin,nom,prenom,groupe);
                    break;
                }
                else{
                    break;
                }
                }
            case (2):
                if(!tabquiz.isEmpty()){
                    boolean passer=false;
                for(int i=0;i<tabquiz.size();i++){
                    boolean exist1=false;
                    int k=0;
                    while(exist1==false && k<tabquiz.get(i).acces_etud().size()){
                        if(ncin.equals(tabquiz.get(i).acces_etud().get(k).access_ncin())==true){
                            passer=true;
                        System.out.println("                   pour cette quiz :");
                        tabquiz.get(i).afficher("ETUDIANT");
                        System.out.println("\n le etudiant de coordonnées : " );
                        tabquiz.get(i).acces_etud().get(k).afficher();
                        System.out.printf("----------------------------------- a comme score %d%%---------------------------------------\n\n",tabquiz.get(i).acces_etud().get(k).access_score());
                        exist1=true;  
                        }
                        k++;
                    }
                    
                }
                if(passer==false){
                    System.out.println("vou n'avez passer aucun quiz pour voir votre score");
                }
                changer=get_out_etud(changer);
                if(changer.equals("N")==true){
                    clearConsole();
                    recursive_etud(tabquiz,tabetudiant,ncin,nom,prenom,groupe);
                    break;
                }
                else{
                    break;
                }}
                else{
                    System.out.println("il ny'a aucun quiz a ce moment");
                    changer=get_out_etud(changer);
                if(changer.equals("N")==true){
                    clearConsole();
                    recursive_etud(tabquiz,tabetudiant,ncin,nom,prenom,groupe);
                    break;
                }
                else{
                    break;
                }
                }
            case (3):
                ArrayList<Integer> tabQUIZ=new ArrayList<>();
                if(tabquiz.isEmpty()==false){
                    for(int i=0;i<tabquiz.size();i++){
                        boolean existi=false;
                        int k=0;
                        while(k<tabquiz.get(i).acces_etud().size() && existi==false){
                            if(tabquiz.get(i).acces_etud().get(k).access_ncin().equals(ncin)==true){
                                tabQUIZ.add(i);
                                existi=true;
                            
                            }
                            k++;
                        }
                    }
                    if(!tabQUIZ.isEmpty()){
                        System.out.println("voici les quiz que vous pouvez voir leur correction");
                        for(int i=0;i<tabQUIZ.size();i++){
                        System.out.println((i+1)+")");
                        System.out.println("-----------------------------------------------QCM "+(i+1));
                        tabquiz.get(tabQUIZ.get(i)).afficher("ETUDIANT");
                        }
                        int correction;
                        
                        do{
                            System.out.println("donner le quiz que vous voulez voir sa correction donnez le nombre qui est associé a cette quiz");
                            correction=sc.nextInt();
                            sc.nextLine();
                        }while(correction>tabQUIZ.size() || correction < 1);
                        System.out.println("voici la correction : "+correction);
                        tabquiz.get(tabQUIZ.get(correction-1)).afficher("ENSEIGNANT");  
                    }
                    else{
                       System.out.println("vous n'avez répondu a aucun quiz pour voir sa correction"); 
                    }
                    }

                else{
                    System.out.println("il ny'a aucune quiz pour vous donnez son corrigée");
                }
                changer=get_out_etud(changer);
                if(changer.equals("N")==true){
                    clearConsole();
                    recursive_etud(tabquiz,tabetudiant,ncin,nom,prenom,groupe);
                    break;
                }
                else{
                    break;
                }
            case (4):
                changer=get_out_etud(changer);
                if(changer.equals("N")==true){
                    clearConsole();
                    recursive_etud(tabquiz,tabetudiant,ncin,nom,prenom,groupe);
                    break;
                }
                else{
                    break;
                }
        }
                
    }

    public static int ens_affiche()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("\n\n\nchoisir ce que vous voulez faire de cette application comme enseignant\n");
                    System.out.println("                 1)créer un quiz\n");
                    System.out.println("                 2)visualiser le Quiz d’un module\n");
                    System.out.println("                 3)supprimer le Quiz d’un module\n");
                    System.out.println("                 4)modifier le Quiz d’un module\n");
                    System.out.println("                 5)Visualiser la liste des étudiants ayant passé le Quiz d’un module, avecle score \n");
                    System.out.println("                 6)Visualiser pour un quiz d’un module, et pour chaque question, le taux de réponses justes et le taux de réponses fausses\n");
                    System.out.println("                 7)quitter l'espace enseignant\n");
                    int rep;
                    System.out.println("\n\n");
                    do{
                        System.out.printf(" Réponse (de (1..7) :");
                        rep=sc.nextInt();
                    }while(rep>7 || rep<1);
        return rep;
    }
    public static void clearConsole() 
    {
                // ANSI escape code for clearing the console
                System.out.print("\033[H\033[2J");
                System.out.flush();
            }
    public static void recursive(ArrayList<QUIZ> tabquiz)
    {
        String changer="";
        int rep=ens_affiche();
        Scanner sc=new Scanner(System.in);
        switch(rep){
            case(1):
                //yaati e nom w module w naamelou création du module
                int i=0;
                String nom_ens;
                do{
                    if(i==0){
                        System.out.println("donner votre nom : ");
                        nom_ens=sc.nextLine();
                        i++;
                    }else{
                        System.out.println("une enseignant ne peut faire qu'une seule quiz");
                        System.out.println("donner votre nom : ");
                        nom_ens=sc.nextLine();
                    }

                }while(exist(tabquiz,nom_ens)==true);
                    System.out.println("donner votre module : ");
                    String mod=sc.nextLine();
                    QUIZ quiz=new QUIZ(mod,nom_ens);
                    quiz.créer();
                    tabquiz.add(quiz);
                changer=get_out_ens(changer);
                if(changer.equals("N")==true){
                    clearConsole();
                    recursive(tabquiz);
                    break;
                }
                else{
                    break;
                }
            case(2):
                if(!tabquiz.isEmpty()){
                    String nom_ense;
                    System.out.println("donner votre nom : ");
                    nom_ense=sc.nextLine();
                    if(exist(tabquiz,nom_ense)==true){
                        int j=0;
                        boolean exist=false;
                        while(j<tabquiz.size() && exist==false){
                            if(tabquiz.get(j).acces().equals(nom_ense)==true){
                                exist=true;
                                tabquiz.get(j).afficher("ENSEIGNANT");
                            }
                            j++;
                        }
                    }
                    else{
                        System.out.println("une enseignant doît avoir créer une quiz pour le visualiser");
                        recursive(tabquiz);
                        break;
                    }
                
                    changer=get_out_ens(changer);
                    if(changer.equals("N")==true){
                        clearConsole();
                        recursive(tabquiz);
                        break;
                    }
                    else{
                        break;
                    }
                }
                else{
                    System.out.println("il ny'a aucune quiz pour le visualiser");
                    changer=get_out_ens(changer);
                    if(changer.equals("N")==true){
                        clearConsole();
                        recursive(tabquiz);
                        break;
                    }
                    else{
                        break;
                    }
                }                 
            case(3):
                if(!tabquiz.isEmpty()){
                    int j=0;
                    String nom_ensei;
                    do{
                        if(j==0){
                            System.out.println("donner votre nom : ");
                            nom_ensei=sc.nextLine();
                            j++;
                        }else{
                            System.out.println("il faut que cette enseignant a un quiz");
                            System.out.println("donner votre nom : ");
                            nom_ensei=sc.nextLine();
                        }
                    }while(exist(tabquiz,nom_ensei)==false);
                    String REP;
                    do{  
                        System.out.println("donner votre module : ");
                        String modu=sc.nextLine();
                        j=0;
                        boolean exist=false;
                        while(j<tabquiz.size() && exist==false){
                            if(tabquiz.get(j).acces().equals(nom_ensei)==true && tabquiz.get(j).accestheme().equals(modu)==true){
                                tabquiz.remove(j);
                                exist=true;
                            }
                            j++;
                        }
                        if(exist==false){
                            System.out.println("le Theme que vous avez écrit n'est pas associée a cette auteur");
                            do{
                                System.out.print("\n\ntu veux changer votre theme o/O pour oui et n/N pour non");
                                REP=sc.nextLine();
                            }while(REP.toUpperCase().equals("O")==false && REP.toUpperCase().equals("N")==false);
                        }
                        else{
                            REP="N";
                            System.out.println("suppression avec succées");
                        }
                    }while(REP.toUpperCase().equals("O")==true); 
                    changer=get_out_ens(changer);
                    if(changer.equals("N")==true){
                        clearConsole();
                        recursive(tabquiz);
                        break;
                    }
                    else{
                        break;
                    }
                }
                else{
                    System.out.println("il ny'a aucune quiz pour le supprimer");
                    changer=get_out_ens(changer);
                    if(changer.equals("N")==true){
                        clearConsole();
                        recursive(tabquiz);
                        break;
                    }
                    else{
                        break;
                    }
                }
            case(4):
                    String REP;
                    int comp=0;
                    if(!tabquiz.isEmpty()){
                        String nom_enseig;
                        do{
                            if(comp==0){
                                System.out.println("donner votre nom : ");
                                nom_enseig=sc.nextLine();
                                comp++;
                            }else{
                                System.out.println("il faut que cette enseignant a une quiz");
                                System.out.println("donner votre nom : ");
                                nom_enseig=sc.nextLine();
                            }
                        }while(exist(tabquiz,nom_enseig)==false);
                        do{
                        System.out.println("donner votre module : ");
                        String modu=sc.nextLine();
                        comp=0;
                        boolean exist=false;
                        while(comp<tabquiz.size() && exist==false){
                            if(tabquiz.get(comp).acces().equals(nom_enseig)==true && tabquiz.get(comp).accestheme().equals(modu)==true){
                                tabquiz.get(comp).modifier();
                                exist=true;
                            }
                            comp++;
                        }
                        if(exist==false){
                            System.out.println("le Theme que vous avez écrit n'est pas associée a cette auteur");
                            do{
                                System.out.print("\n\ntu veux changer votre theme o/O pour oui et n/N pour non");
                                REP=sc.nextLine();
                            }while(REP.toUpperCase().equals("O")==false && REP.toUpperCase().equals("N")==false);
                        }
                        else{  
                            REP="N";
                            System.out.println("modification avec succées");
                        }
                        }while(REP.toUpperCase().equals("O")==true);
                
                        changer=get_out_ens(changer);
                
                        if(changer.equals("N")==true){
                            clearConsole();
                            recursive(tabquiz);
                            break;
                        }
                        else{
                    
                            break;
                        }
                    }
                    else{
                        System.out.println("il ny'a aucune quiz pour le modifié");
                        changer=get_out_ens(changer);
                        if(changer.equals("N")==true){
                            clearConsole();
                            recursive(tabquiz);
                            break;
                        }
                        else{
                            break;
                        }    
                    }
            case(5):
                if(!tabquiz.isEmpty()){
                int comp1=0;
                String nom_enseig;
                        do{
                            if(comp1==0){
                                System.out.println("donner votre nom : ");
                                nom_enseig=sc.nextLine();
                                comp1++;
                            }else{
                                System.out.println("il faut que cette enseignant a une quiz");
                                System.out.println("donner votre nom : ");
                                nom_enseig=sc.nextLine();
                            }
                        }while(exist(tabquiz,nom_enseig)==false);
                
                do{
                        System.out.println("donner votre module : ");
                        String modu=sc.nextLine();
                        comp1=0;
                        boolean exist=false;
                        while(comp1<tabquiz.size() && exist==false){
                            if(tabquiz.get(comp1).acces().equals(nom_enseig)==true && tabquiz.get(comp1).accestheme().equals(modu)==true){
                                System.out.println("les etudiant qui ont passé le quiz crée par "+nom_enseig+" qui enseigne le module "+modu + " sont : ");
                                     for(int k=0;k<tabquiz.get(comp1).acces_etud().size();k++){
                                         System.out.printf("           etudiant %d : ",comp1+1);
                                        tabquiz.get(comp1).acces_etud().get(k).afficher();
                                    }
                                
                                exist=true;
                            }
                            comp1++;
                        }
                        if(exist==false){
                            System.out.println("le Theme que vous avez écrit n'est pas associée a cette auteur");
                            do{
                                System.out.print("\n\ntu veux changer votre theme o/O pour oui et n/N pour non");
                                REP=sc.nextLine();
                            }while(REP.toUpperCase().equals("O")==false && REP.toUpperCase().equals("N")==false);
                        }
                        else{  
                            REP="N";
                        }
                        }while(REP.toUpperCase().equals("O")==true);
                
                
                changer=get_out_ens(changer);
                if(changer.equals("N")==true){
                    clearConsole();
                    recursive(tabquiz);
                    break;
                }
                else{
                    break;
                }
                } 
                else{
                        System.out.println("il ny'a aucune quiz");
                        changer=get_out_ens(changer);
                        if(changer.equals("N")==true){
                            clearConsole();
                            recursive(tabquiz);
                            break;
                        }
                        else{
                            break;
                        }    
                    }
            case(6):
                    if(!tabquiz.isEmpty()){
                int comp1=0;
                String nom_enseig;
                        do{
                            if(comp1==0){
                                System.out.println("donner votre nom : ");
                                nom_enseig=sc.nextLine();
                                comp1++;
                            }else{
                                System.out.println("il faut que cette enseignant a une quiz");
                                System.out.println("donner votre nom : ");
                                nom_enseig=sc.nextLine();
                            }
                        }while(exist(tabquiz,nom_enseig)==false);
                
                do{
                        System.out.println("donner votre module : ");
                        String modu=sc.nextLine();
                        comp1=0;
                        boolean exist=false;
                        while(comp1<tabquiz.size() && exist==false){
                            if(tabquiz.get(comp1).acces().equals(nom_enseig)==true && tabquiz.get(comp1).accestheme().equals(modu)==true){
                                tabquiz.get(comp1).visualisertauxrepQCM();
                                exist=true;
                            }
                            comp1++;
                        }
                        if(exist==false){
                            System.out.println("le Theme que vous avez écrit n'est pas associée a cette auteur");
                            do{
                                System.out.print("\n\ntu veux changer votre theme o/O pour oui et n/N pour non");
                                REP=sc.nextLine();
                            }while(REP.toUpperCase().equals("O")==false && REP.toUpperCase().equals("N")==false);
                        }
                        else{  
                            REP="N";
                        }
                        }while(REP.toUpperCase().equals("O")==true);
                
                
                changer=get_out_ens(changer);
                if(changer.equals("N")==true){
                    clearConsole();
                    recursive(tabquiz);
                    break;
                }
                else{
                    break;
                }
                }
                    else{
                        System.out.println("il ny'a aucune quiz ");
                        changer=get_out_ens(changer);
                if(changer.equals("N")==true){
                    clearConsole();
                    recursive(tabquiz);
                    break;
                }
                else{
                    break;
                }
                    }
                case(7):
                    break;
        }         
    }
    public static boolean exist_etud(String ncin,ArrayList<etudiant>tabetudiant )
    {
        int i=0;
        boolean exis=false;
        while(i<tabetudiant.size() && exis==false){
            if(tabetudiant.get(i).access_ncin().equals(ncin)==true){
                exis=true;
            }
            i++;
        }
        return exis;
    }
    public static boolean exist(ArrayList<QUIZ>tabquiz,String nom_ens)
    {
        int i=0;
        boolean exis=false;
        while(i<tabquiz.size() && exis==false){
            if(tabquiz.get(i).acces().equals(nom_ens)==true){
                
                exis=true;
            }
            i++;
        }
        return exis;
    }
    public static void main(String[] args) {
        String code;
        String continuer;
        ArrayList<QUIZ> tabquiz = new ArrayList<>();
        ArrayList<etudiant> tabetudiant = new ArrayList<>();
        Scanner sc=new Scanner(System.in);
        String etudiant;
        String enseignant;
        String code_ens;
        do{
        do{
        System.out.printf("est ce que vous êtes un enseignant ? O/o pour dire oui N/n pour non : ");
        enseignant=sc.nextLine();
        enseignant=enseignant.toUpperCase();
        }while(enseignant.equals("O")!=true && enseignant.equals("N")!=true );
        if(enseignant.equals("O")==true){
                int comp=5;
                do{
                    comp--;
                    System.out.println("il vous reste "+comp+" tentative ");
                   System.out.printf("donner le code des enseignant : ");
                    code_ens=sc.nextLine(); 
                    code_ens=code_ens.toUpperCase();
                }while(comp>1 && code_ens.equals("ADMIN")!=true);
                
                if(code_ens.equals("ADMIN")==true){
                    recursive(tabquiz);                       
                }
            }
        //pour étudiant
        do{
            System.out.printf("est ce que vous êtes un étudiant ? O/o pour dire oui N/n pour non : ");
            etudiant=sc.nextLine();
            etudiant=etudiant.toUpperCase();
        }while(etudiant.equals("O")!=true && etudiant.equals("N")!=true );
        if(etudiant.equals("O")==true){
            int comp=5;
            do{
                comp--;
                System.out.println("il vous reste "+comp+" tentative ");
                System.out.printf("donner le code des etudiant : ");
                code=sc.nextLine(); 
                code=code.toUpperCase();
            }while(comp>1 && code.equals("ETUDIANT")!=true);
            if(code.equals("ETUDIANT")==true){
                String nom;
                String prenom;
                String groupe;
                String ncin;
                String choix;
                do{
                    System.out.print(" donner votre nom : ");
                    nom=sc.nextLine();
                    System.out.print(" donner votre prenom : ");
                    prenom=sc.nextLine();
                    System.out.print(" donner votre groupe : ");
                    groupe=sc.nextLine();
                    do{
                        System.out.print(" donner votre ncin : ");
                        ncin=sc.nextLine();
                    }while(ncin.length()!=8);
                    if(exist_etud(ncin,tabetudiant)==false){
                        System.out.println("vous êtes un nouvelle alors tu sera ajoutée a la liste des étudiant");
                        etudiant etud=new etudiant(nom,prenom,groupe,ncin,0);
                        tabetudiant.add(etud);
                    }
                    recursive_etud(tabquiz,tabetudiant,ncin,nom,prenom,groupe); 
                    do{
                        System.out.println("tu veux entrer comme un autre étudiant o/O pour oui et n/N pour non");
                        choix=sc.nextLine();
                        choix=choix.toUpperCase();
                    }while(choix.equals("N")==false && choix.equals("O")==false);
                }while(choix.equals("O")==true);
                }
        }
        //cas particulier
        
        if(etudiant.equals("N")==true&& enseignant.equals("N")==true){
            System.out.printf("cette application n'est pas déstinée à vous ");
            continuer="N";
        }
        else{
            do{
            System.out.println("est ce que vous voulez continuer et entrer comme un etudiant si vous ête un etudiant ou entrer comme un enseignant s vous êtes comme un enseignant o/O pour oui et n/N pour non");
            continuer=sc.nextLine();
            continuer=continuer.toUpperCase();
        }while(continuer.equals("O")==false && continuer.equals("N")==false);
        }
        }while( continuer.equals("O")==true);
    }
}
