/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projet_poo;

import java.util.*;

/**
 *
 * @author ali abdelhak
 */
public class QUIZ {
    private String Theme;//c'est le module
    private String auteur;//ce qui va créer le quiz
    private ArrayList<etudiant> tabetud = new ArrayList<>();    
    private ArrayList<QCM> tabqcm = new ArrayList<>();
    //ngued l constructeur
    public QUIZ(String them,String auteu){
        Theme=them;
        auteur=auteu;
    }
    public ArrayList<QCM> access_qcm(){
        return tabqcm;  
    }
    public void ajouteretudiant(etudiant et){
        tabetud.add(et);
    }
    public String acces(){
        return auteur;
    }
    public String accestheme(){
        return Theme;
    }
    public ArrayList<etudiant> acces_etud(){
        return tabetud;
    }
    
    public void créer(){
        Scanner sc=new Scanner(System.in);
        int i=1;
        QCM qc=new QCM();
        qc.creer(i);
        String rep;
        tabqcm.add(qc);
        do{
            i++;
            qc=new QCM();
            qc.creer(i);
            tabqcm.add(qc);
            System.out.print("est ce que vous voulez ajouter une qcm (O/o)pour oui (n/N)"); 
            rep=sc.next();
            rep=rep.toUpperCase();
        }while(rep.equals("O")==true);
    }
    public void afficher(String type){
        System.out.println("\n\nl'auteur de ce quiz est : " + auteur );
        System.out.println("le théme que ce enseignant l'étudie est  : "+ Theme);
        for(int i=0;i<tabqcm.size();i++){
            tabqcm.get(i).visualiser(type);
        }
    }
    public void visualisertauxrepQCM(){
        
        System.out.println("\n\n auteur de QCM : "+auteur);
        System.out.println("Theme de QCM : "+Theme);
        
        if(tabqcm.get(0).access_tabrep().size()>0){
        for(int i=0;i<tabqcm.size();i++){
            int tauxjuste=0;
            int tauxfausse=0;
            tabqcm.get(i).visualiser("ETUDIANT");
            for(int j=0;j<tabqcm.get(i).access_tabrep().size();j++){
                //taux de reponses juste
                if(tabqcm.get(i).access_tabrep().get(j)==1){
                    tauxjuste++;
                }
                //taux de reponses fausses
                else{
                    tauxfausse++;
                }
            }
            System.out.println("le taux des reponses juste de ce QCM est : "+tauxjuste*100/tabqcm.get(i).access_tabrep().size() + "%");
            System.out.println("le taux des reponses fausse de ce QCM est : "+tauxfausse*100/tabqcm.get(i).access_tabrep().size() + "%");
            
            
        }}else{
                System.out.println("\n\nil ny'a aucun étudiant a passer cette quiz");
            }
        
    }
    public void modifier(){
        System.out.println("---------------------------------------------------------------");
        System.out.println("---------------------modification de la quiz--------------------- ");
        for(int i=0;i<tabqcm.size();i++){
            tabqcm.get(i).modifier();
        }
    }
    //ngued affichage ll quiz w lmodification w zeda suppression 

}
