/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projet_poo;

import java.util.*;

/**
 *
 * @author ali abdelhak
 */
public class QCM {
    private Scanner sc=new Scanner(System.in);
    private int num_quest;
    private String text;
    private ArrayList<Integer> tabrep = new ArrayList<>();
    private ArrayList<OPTION> tabop = new ArrayList<>();
    public QCM(){
        num_quest=0;
        text="";
    }
    public ArrayList<OPTION> access_tabop(){
        return tabop;
    }
    public ArrayList<Integer> access_tabrep(){
        return tabrep;
    }
    public void settabrep(int reponse){
        tabrep.add(reponse);
    }
    public String access_text(){
        return text;
    }
    public void creer(int numquest){
        num_quest=numquest;
        System.out.print("\ndonner le texte de le numéro de question suivant "+numquest+" : ");
        String texte=sc.nextLine();
        text=texte;
        String rep;
        System.out.print("\ndonner la premiére option ");
        //pour les options
        System.out.print("\ndonner le text de votre option : ");
        String textop=sc.nextLine();
        String repop;
        do{
            System.out.print("\ndonner la réponse de votre option (true)/(false): ");
            repop=sc.next();
            repop=repop.toUpperCase();
        }while(repop.equals("TRUE")==false && repop.equals("FALSE")==false );
        OPTION op=new OPTION(textop,repop);
        tabop.add(op);
        op.afficher("ENSEIGNANT");
        String textop1;
        do{
            System.out.print("\ndonner le text de votre option : ");
            sc.nextLine();
            textop1=sc.nextLine();
            do{
            System.out.print("\ndonner la réponse de votre option (true)/(false): ");
            repop=sc.next();
            repop=repop.toUpperCase();
            }while(repop.equals("TRUE")==false && repop.equals("FALSE")==false );
            OPTION op1=new OPTION(textop1,repop);
            tabop.add(op1);
            op1.afficher("ENSEIGNANT");
            do{
                System.out.print("\nest ce que vous voulez ajouter une option (O/o)pour oui (n/N)"); 
                rep=sc.next();
                rep=rep.toUpperCase();
            }while(rep.equals("O")==false && rep.equals("N")==false);
        }while(rep.equals("O")==true );
    }
    public void visualiser(String type ){
        System.out.println(" \n"+num_quest+") "+text + " : ");
        for(int i=0 ; i< tabop.size();i++){
            tabop.get(i).afficher(type);
        }
    }
    public void modifier(){
        this.visualiser("ENSEIGNANT");
        String rep;
        sc.nextLine();
        do{
            System.out.println("si vous voulez changer le text de qcm tapez(o/O)pour oui et (n/N)pour non");  
            rep=sc.nextLine();
        }while(rep.toUpperCase().equals("O")==false && rep.toUpperCase().equals("N")==false);
        if(rep.toUpperCase().equals("O")==true){
            String texte;
            System.out.println(" text QCM : ");
            texte=sc.nextLine();
            text=texte;
        }
        for(int i=0;i<tabop.size();i++){
            System.out.println("option   :   "+i);
            tabop.get(i).afficher("ENSEIGNANT");
            tabop.get(i).modifier();
        }
        //on modifie pour chaque qcm le text et pour chaque option les text et les réponses
    }

}
